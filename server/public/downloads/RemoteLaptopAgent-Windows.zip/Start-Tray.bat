@echo off
start WindowsAgent.exe --tray
